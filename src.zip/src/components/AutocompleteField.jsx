const AutocompleteField = (props) => {
  return <></>;
};

// TODO: Implement passed props
AutocompleteField.defaultProps = {};

export default AutocompleteField;
